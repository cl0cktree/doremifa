document.addEventListener('DOMContentLoaded', ()=>{
    // Select Box Event
    const selectBoxEl = document.querySelectorAll('.cm_select_wrap');
                
    selectBoxEl.forEach( el => {
        el.addEventListener('click', function(event) {
            const targetOption  = event.target;
            const isOptionEl    = targetOption.classList.contains('cm_opt');

            if(isOptionEl) selectOption(targetOption);

            toggleSelectBox(el);
        });
    });

    function toggleSelectBox(el) {

        let isOption = el.classList.contains('act');
        let arr      = el.querySelector(".cm_arr");

        if(isOption) {
            el.classList.remove('act');
            el.style.zIndex = 0;
            arr.classList.remove('act');

        } else {
            allSelectBoxClose();
            el.classList.add('act');
            el.style.zIndex = 1;
            arr.classList.add('act');
        }
    }

    function selectOption(optionEl) {

        const selectParent = optionEl.closest(".cm_select_wrap");
        const selectValue  = selectParent.querySelector(".cm_select_value");
        const values        = optionEl.dataset.value;
        
        selectValue.setAttribute('data-value', values);
        selectValue.textContent = optionEl.textContent;
        // console.log(selectValue.dataset.value);
    }

    function allSelectBoxClose () {

        const allSelectBoxEl = document.querySelectorAll(".cm_select_wrap");

        allSelectBoxEl.forEach( el => {
            el.classList.remove("act");
            el.style.zIndex = 0;
            el.querySelector('.cm_arr').classList.remove('act');
        });
    }
    
    document.addEventListener("click", function (event) {

        const targetEl = event.target;
        const isSelect = targetEl.classList.contains("cm_select_wrap") || targetEl.closest(".cm_select_wrap");
        
        if (isSelect) return;

        allSelectBoxClose();
    });


    // Tab Box Event
    const tabMenu = document.querySelectorAll('.tab_wrap span');
    const tabContent = document.querySelectorAll('.tab_content > article');

    function showContent(idx){

        tabContent.forEach(function(item){
            item.style.display = 'none';
            item.classList.remove('act');
        });
        tabContent[idx].style.display = 'block';
        tabContent[idx].classList.add('act');
        shwoTab(idx);
    }
    
    function shwoTab(idx) {
        tabMenu.forEach(function(item){
            item.classList.remove('act');
        });
        tabMenu[idx].classList.add('act');
    }

    showContent(0);

    tabMenu.forEach(function(item, idx){
        item.addEventListener('click', function(event){
            event.preventDefault();
            showContent(idx);
        });
    });

    // Pop up Event
    const lock   = document.querySelector('body'),
        popUp    = document.querySelector('.po_area'),
        popClose = document.querySelector('.po_close'),
        popOpen  = document.querySelector('#product');
    
        popOpen.addEventListener('click', function() {
            popUp.style.display = 'block';
            lock.classList.add('scroll_lock');  // 스크롤 막음
        })
        popClose.addEventListener('click', function() {
            popUp.style.display = 'none';
            lock.classList.remove('scroll_lock');
        })

    //Tree Menu
    const pos = document.querySelectorAll('.ico_pos'),
        child = document.querySelectorAll('.children');

        pos.forEach( el => {

            el.addEventListener('click', function() {
                toggleClassEvent(this, 'act');
                toggleClassEvent(this.nextElementSibling, 'act')
            });
        });

        function toggleClassEvent (el, className) {
            if(el.classList.contains(className)) {
                el.classList.remove(className);
            } else {
                el.classList.add(className);
            }
        }
})