/*!
 * AUIGrid 3.0.12 License
 * License Type : Evaluation(Trial) Version
 * Authorized Domain(or IP) : localhost,127.0.0.1
 * Expiration Date : 2023-12-24
 * www.auisoft.net
 */
 /* eslint-disable */
var AUIGridLicense = "eyJjdCI6ImlxNEJXYU45M1hZY050Z2VEWk5qcm1Vdyt5ZFpTNUJqUFhqMDQwaFgwbVBIOXdxV25qaW11T0M3M1wvK0tHUFlJZWdVNjQycm8xMm10QlhDV3ZJXC9tMXFhaVVyMWZ2ZGlcL21WQUliV1IyUlF3PSIsIml2IjoiMmMyZGRhZjhlNTU5YzRmNWUxZTQyNTQ2YmQ5N2ZmZWIiLCJzIjoiZjM2ZDQwMzYyZjMxYjk1OCJ9";
if (typeof window !== "undefined") window.AUIGridLicense = AUIGridLicense;