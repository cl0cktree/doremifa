/*!
* AUIGrid 3.0.13 License
* License Type : Enterprise Dev License
* Authorized Domain(or IP) : 10.100.23.82, ec2-15-164-116-230.ap-northeast-2.compute.amazonaws.com
* Expiration Date : 2024-09-30
* www.auisoft.net
*/
/* eslint-disable */
var AUIGridLicense = "eyJjdCI6IlRMYVJCT3BGSXhNT1l5c25YRGRJUFJiVVBMTElVWWk0ZGR3cXRMYkh2VHFsbE5NY21cL1wvXC9rdDZBR3h4M28zMjFxcFprQ3hYSjFLam1NdTdLOEtnTGpKdGZEcUJMVnR3eUhVNWpqcFZNaTc1MHRwNDlGV0pBZGJCWkdiZHNBZ3JjallnRVdRWFNVekxCQ2tTcDByTTlIQlFVd3RGanNcL3JmdTBnTmRzdW55M2xWcXE4MDNvc0R4aDYrcmhqeXEyTnMiLCJpdiI6IjU4MmJhYjk4YjVkNTdiMDlmNDUyMDUzMjE0ZDY2NGZlIiwicyI6IjA1ZTBmNzBiMTg2ZDNlMzIifQ==";
if (typeof window !== "undefined") window.AUIGridLicense = AUIGridLicense;