$(function(){
	/*loader 제어*/
	$(document).ready(function(){
		//-----셀랙트 박스 구현 부분
		var $select_lange = $('.select_lange');
		var $search_list = $('.search_list');
		var $sel_options = $('.search_list').children('li').find('button');
		var $select_input = $('.select_input');

		$select_lange.on('click', function(e){
			$search_list.toggleClass('display_none');
		});

		$sel_options.on('click',function(e){
			$select_lange.text($(this).parent('li').data('option'));
			$search_list.addClass('display_none');
		});

		$select_input.on('click',function(e){
			$search_list.addClass('display_none');
		});
		//-------------------------

		// -------컨펌창 구현-------
		$('.close_btn').on('click',function(e){
			$('.popup_filter').removeClass('display_none');
			$('.modal_confirm_1').removeClass('display_none');
		});
		$('.save_all_btn').on('click',function(e){
			$('.popup_filter').removeClass('display_none');
			$('.modal_confirm_2').removeClass('display_none');
		});
		$('.cancle_btn').on('click',function(e){
			$('.popup_filter').addClass('display_none');
			$('.modal_confirm_1').addClass('display_none');
		});
		// ------------------------

		// ------textarea 자동 확장 기능 구현
		var auto_text = document.querySelectorAll('.auto_textarea');

		[].forEach.call(auto_text,function(this_val){
			this_val.addEventListener('keydown',auto_con,false);
			this_val.addEventListener('keyup',auto_con,false);
		});

		function auto_con(){
			var auto_this = document.getElementById('auto_textarea_'+this.dataset.index);
			if(auto_this.scrollHeight > auto_this.clientHeight){ //textarea height 확장
				auto_this.style.height = auto_this.scrollHeight + "px";
				console.log('over drop = '+this.dataset.index);
			}
			else{ //textarea height 축소
				auto_this.style.height = (auto_this.scrollHeight-18) + "px";
			}
			console.log('auto_this.scrollHeight = '+auto_this.scrollHeight+' / auto_this.clientHeight = '+auto_this.clientHeight);
		};
		// --------------------------

		// ------- 데이트픽커 부분 ---
		function cfDatepicker(datepick_field_1){
			$('#datepick_field_1').datepicker({
				showOn: "both",
				buttonImage: "/images/icons/flags/US.png",
				buttonImageOnly: true, // 버튼에 있는 이미지만 표시한다.
				changeMonth: true, // 월을 바꿀수 있는 셀렉트 박스를 표시한다.
				changeYear: true, // 년을 바꿀 수 있는 셀렉트 박스를 표시한다.
				minDate: '-10y', // 현재날짜로부터 10년이전까지 년을 표시한다.
				nextText: '다음 달', // next 아이콘의 툴팁.
				prevText: '이전 달', // prev 아이콘의 툴팁.
				numberOfMonths: [1,1], // 한번에 얼마나 많은 월을 표시할것인가. [2,3] 일 경우, 2(행) x 3(열) = 6개의 월을 표시한다.
				tepMonths: 3, // next, prev 버튼을 클릭했을때 얼마나 많은 월을 이동하여 표시하는가. 
				yearRange: 'c-10:c+10', // 년도 선택 셀렉트박스를 현재 년도에서 이전, 이후로 얼마의 범위를 표시할것인가.
				showButtonPanel: true, // 캘린더 하단에 버튼 패널을 표시한다. 
				currentText: '오늘 날짜' , // 오늘 날짜로 이동하는 버튼 패널
				closeText: '닫기',  // 닫기 버튼 패널
				dateFormat: "yy-mm-dd", // 텍스트 필드에 입력되는 날짜 형식.
				//showAnim: "slide", //애니메이션을 적용한다.
				showMonthAfterYear: true , // 월, 년순의 셀렉트 박스를 년,월 순으로 바꿔준다. 
				dayNamesMin: ['월', '화', '수', '목', '금', '토', '일'], // 요일의 한글 형식.
				monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],// 월의 한글 형식.
			});
		};

		$('.datepicker_btn').on('click', function(e){
			cfDatepicker(datepick_field_1);
		});
		// -----------------------------
	});
	return false;
});
