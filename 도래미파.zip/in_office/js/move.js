$(function(){
	/*loader 제어*/
	$(document).ready(function(){
		//-----검색 부분 셀랙트 박스 구현 부분
		var $select_lange = $('.select_lange');
		var $search_list = $('.search_list');
		var $sel_options = $('.search_list').children('li').find('button');
		var $select_input = $('.select_input');

		$select_lange.on('click keydown focusin focusout', function(e){
			if(e.type=='click'){
				$search_list.toggleClass('display_none');
			}
			if(e.type=='keydown'){
				$search_list.removeClass('display_none');
			}
			if(e.type=='focusin'){
				$search_list.addClass('display_none');
			}
			if(e.type=='focusout'){
				$search_list.removeClass('display_none');
			}
		});
		$('.search_list').on('focusin keydown', function(e){
			if(e.type=='focusin'){
				$search_list.removeClass('display_none');
			}
		});

		$sel_options.on('click focusout',function(e){
			if(e.type=='click'){
				$select_lange.text($(this).parent('li').data('option'));
				console.log('option = '+$(this).parent('li').data('option')+' / index = '+$(this).parent('li').data('index'));
				$(".hidden_select").find('option').removeAttr("selected");
				$(".hidden_select").find('option').eq($(this).parent('li').data('index')-1).attr("selected", "selected");
				$search_list.addClass('display_none');
			}
			// if(e.type=='focusout'){
			// 	$search_list.addClass('display_none');
			// }

		});

		$select_input.on('click focusin',function(e){
			$search_list.addClass('display_none');
		});
		//-------------------------

		//-----중복 된 제목 코드 확인 부분 셀랙트 박스 구현 부분
		var $code_select_open = $('.code_select_open');
		var $another_code_list = $('.another_code_list');
		var $code_options = $('.another_code_list').children('li').find('button');
		var $one_section_input = $('.one_section_input');

		$code_select_open.on('click keydown focusin focusout', function(e){
			if(e.type=='click'){
				$another_code_list.toggleClass('display_none');
			}
			if(e.type=='keydown'){
				$another_code_list.removeClass('display_none');
			}
			if(e.type=='focusin'){
				$another_code_list.addClass('display_none');
			}
			if(e.type=='focusout'){
				$another_code_list.removeClass('display_none');
			}
		});
		$('.another_code_list').on('focusin keydown', function(e){
			if(e.type=='focusin'){
				$another_code_list.removeClass('display_none');
			}
		});

		$code_options.on('click focusout',function(e){
			if(e.type=='click'){
				$code_select_open.text($(this).parent('li').data('option'));
				console.log('option = '+$(this).parent('li').data('option')+' / index = '+$(this).parent('li').data('index'));
				$(".anoter_code_selectbox").find('option').removeAttr("selected");
				$(".anoter_code_selectbox").find('option').eq($(this).parent('li').data('index')-1).attr("selected", "selected");
				$another_code_list.addClass('display_none');
			}
			// if(e.type=='focusout'){
			// 	$another_code_list.addClass('display_none');
			// }

		});

		$one_section_input.on('click focusin',function(e){
			$another_code_list.addClass('display_none');
		});
		//----------------------------

		// -------컨펌창 구현-------
		var summon_file_this;  // 업로드 파일 명 공유 변수 - 하단 삭제 버튼과 연동하여 사용.
		$('.close_btn').on('click',function(e){
			$('.popup_filter').removeClass('display_none');
			$('.modal_confirm_1').removeClass('display_none');
			summon_file_this = $(this).parent();
			console.log(summon_file_this);
		});
		$('.save_all_btn').on('click',function(e){
			$('.popup_filter').removeClass('display_none');
			$('.modal_confirm_2').removeClass('display_none');
		});
		$('.cancle_btn').on('click',function(e){
			$('.popup_filter').addClass('display_none');
			$('.modal_confirm_1').addClass('display_none');
		});
		// ------------------------

		// ------textarea 자동 확장 기능 구현
		var auto_text = document.querySelectorAll('.auto_textarea');

		[].forEach.call(auto_text,function(this_val){
			this_val.addEventListener('keydown',auto_con,false);
			this_val.addEventListener('keyup',auto_con,false);
		});

		function auto_con(){
			var auto_this = document.getElementById('auto_textarea_'+this.dataset.index);
			if(auto_this.scrollHeight > auto_this.clientHeight){ //textarea height 확장
				auto_this.style.height = auto_this.scrollHeight + "px";
				console.log('over drop = '+this.dataset.index);
			}
			else{ //textarea height 축소
				auto_this.style.height = (auto_this.scrollHeight-18) + "px";
			}
			console.log('auto_this.scrollHeight = '+auto_this.scrollHeight+' / auto_this.clientHeight = '+auto_this.clientHeight);
		};
		// --------------------------

		// ------- 데이트픽커 부분 ---
		// function cfDatepicker(data_rage_01){
		// 	$('#data_rage_01').datepicker({
		// 		showOn: "both",
		// 		buttonImage: "../images/btn_date.png",
		// 		buttonImageOnly: true, // 버튼에 있는 이미지만 표시한다.
		// 		changeMonth: true, // 월을 바꿀수 있는 셀렉트 박스를 표시한다.
		// 		changeYear: true, // 년을 바꿀 수 있는 셀렉트 박스를 표시한다.
		// 		minDate: '-10y', // 현재날짜로부터 10년이전까지 년을 표시한다.
		// 		nextText: '다음 달', // next 아이콘의 툴팁.
		// 		prevText: '이전 달', // prev 아이콘의 툴팁.
		// 		numberOfMonths: [1,1], // 한번에 얼마나 많은 월을 표시할것인가. [2,3] 일 경우, 2(행) x 3(열) = 6개의 월을 표시한다.
		// 		tepMonths: 3, // next, prev 버튼을 클릭했을때 얼마나 많은 월을 이동하여 표시하는가. 
		// 		yearRange: 'c-10:c+10', // 년도 선택 셀렉트박스를 현재 년도에서 이전, 이후로 얼마의 범위를 표시할것인가.
		// 		showButtonPanel: true, // 캘린더 하단에 버튼 패널을 표시한다. 
		// 		currentText: '오늘 날짜' , // 오늘 날짜로 이동하는 버튼 패널
		// 		closeText: '닫기',  // 닫기 버튼 패널
		// 		dateFormat: "yy.mm.dd dayname", // 텍스트 필드에 입력되는 날짜 형식.
		// 		//showAnim: "slide", //애니메이션을 적용한다.
		// 		showMonthAfterYear: true , // 월, 년순의 셀렉트 박스를 년,월 순으로 바꿔준다. 
		// 		dayNamesMin: ['월', '화', '수', '목', '금', '토', '일'], // 요일의 한글 형식.
		// 		monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],// 월의 한글 형식.
		// 	});
		// };

		// $('#data_rage_01').on('click', function(e){
		// 	cfDatepicker(data_rage_01);
		// });

		// -----------------------------

		// ------ json 에서 데이터 가져와 input 에 삽입----
		$('.aui-grid-table').find('tr').on('mousedown mouseup', function(e){
			var json_data = '../gridData_1.json';
			var $rowId = $(this).find('td').eq(0).text();
			var data_arr = [];
			var auto_this = document.getElementById('auto_textarea_1');

			console.log('this = '+ $rowId);

			if(e.type=="mousedown"){
				$.getJSON(json_data, function(data){
					$.each(data, function(I, item){
						if($rowId==item.id){
							data_arr = item.id+' | '+item.date;
							console.log(item.condition);
							$('#business_input').val(item.business);
							$('#codeNum').val(item.id);
							$('#writeDay').val(item.date);
							$('#date_start').val(item.startDate);
							$('#date_end').val(item.endDate);
							$('#data_price').val(item.price);
							$('#auto_textarea_1').val(item.businessWord);
							$('.all_badge_wrap').find('.btn_badge_type2').children('a').click();

							var badge_index_json;
							var badge_value_json;
							var split_all_index = item.badgeIndex.split(' | ');
							var split_all_value = item.badgeValue.split(' | ');
							
							$("#btn2").removeClass('display_none');
							if((Object.keys(item.badgeIndex).length>0)&&(Object.keys(item.badgeValue).length>0)){
								if(split_all_index.length>1){
									badge_index_json = split_all_index;
									badge_value_json = split_all_value;
									for(i=0;i<split_all_index.length;++i){
										var a = 1;
										var src_all_index = split_all_index[i];
										var src_all_value = split_all_value[i];

										var out_html = '<div class="btn_badge_type2" data-index="'+src_all_index+'" data-value="'+src_all_value+'">'+src_all_value+'<a href="#" onclick="fnc_remove2(this)">닫기버튼</a></div>';
										$("#btn2").append(out_html);
										$("#srchBBB").val("");
										$('.data_sch_list_2').addClass('display_none');
										$('.data_sch_list_2').children('.all_src_data_option_'+src_all_index).addClass('display_none');
										console.log(src_all_index);
									}

									console.log('split_all_index = '+split_all_index+' / split_all_value = '+split_all_value+' / length ='+split_all_index.length);
								}else{
									badge_index_json = item.badgeIndex;
									badge_value_json = item.badgeValue;

									var out_html = '<div class="btn_badge_type2" data-index="'+badge_index_json+'" data-value="'+badge_value_json+'">'+badge_value_json+'<a href="#" onclick="fnc_remove2(this)">닫기버튼</a></div>';
									$("#btn2").append(out_html);
									$("#srchBBB").val("");
									$('.data_sch_list_2').addClass('display_none');
									$('.data_sch_list_2').children('.all_src_data_option_'+badge_index_json).addClass('display_none');
								};
								
								all_badge_arr();
							}

							// console.log(badge_index_json+' / json / '+badge_value_json);
							
						}
					});
				});
			}
			
			if(e.type=="mouseup"){
				if(auto_this.scrollHeight>28){
					auto_this.style.height = auto_this.scrollHeight + "px";
				}
				console.log('auto_this = '+auto_this.scrollHeight);
			}

			
			// if(auto_this.scrollHeight > 0){ //textarea height 확장
			// 	auto_this.style.height = 40+auto_this.scrollHeight + "px";
			// 	console.log('fire!!!!!!!');
			// }
		});
		// -----------------------------------------------
		
		// ----- 콤보박스 및 벳지 컨트롤 --------------------
		var index_all_1;
		var value_all_1;
		
		$("#srchAAA").on("change click focusin focusout keydown keyup", function(e){
			var in_html_1 = '<div class="btn_badge_type1" data-index="'+index_all_1+'" data-value="'+$("#srchAAA").val()+'">'+$("#srchAAA").val()+'<a href="#" onclick="fnc_remove1(this)">닫기버튼</a></div>';
			
			if(e.type=='focusin'){
				$('.data_sch_list_1').removeClass('display_none');
				$(".solo_src_data_option").show();
			}
			if(e.type=='focusout'){
				$('.data_sch_list_1').addClass('display_none');
				$(".solo_src_data_option").show();
			}
			if(e.type=='change'){
				$("#btn1").append(in_html_1);
				$("#btn1").removeClass('display_none');
				$("#srchAAA").val("");
			}
			if((e.type=='keydown')&&(e.keyCode==13)){
				e.preventDefault();
				e.stopPropagation();
				console.log('앤터 입력');
			}
			if(e.type=='keyup'){// input 입력 시 입력한 값이 포함 된 검색어 만 노출.
				var k = $(this).val();
				$(".solo_src_data_option").hide();
				var temp = $(".solo_src_data_option:contains('" + k + "')");
				$(temp).show();
			}
        });

		$('.data_form').find('.data_sch_list_1').on('mousedown keydown focusin', 'button', function(e){
			console.log('button click.');
			$("#srchAAA").val("");
			$('.btn_badge_type1').remove();
			value_all_1 = $(this).parent('li').data('value');
			index_all_1 =  $(this).parent('li').data('index');
			$('.data_sch_list_1').addClass('display_none');
			if($(this).parent().is('#etc_solo_sel')){
				$('.popup_filter').removeClass('display_none');
				$(".modal_confirm_4").removeClass('display_none');
			}else{
				var out_html_1 = '<div class="btn_badge_type1" data-index="'+index_all_1+'" data-value="'+value_all_1+'">'+value_all_1+'<a href="#" onclick="fnc_remove1(this)">닫기버튼</a></div>';
				$("#btn1").append(out_html_1);
				$("#btn1").removeClass('display_none');
				$("#srchAAA").val("");
				solo_badge_arr();
			}
		});

		$("#srchBBB").on("change click focusin focusout keydown keyup", function(e){
            var result_select = false;
            var max_count;
            var all_wrap_width;
			var in_html_2 = '<div class="btn_badge_type2">'+$("#srchBBB").val()+'<a href="#" onclick="fnc_remove2(this)">닫기버튼</a></div>';

			if(e.type=='focusin'){
				$('.data_sch_list_2').removeClass('display_none');
				$(".all_src_data_option").show();
			}
			if(e.type=='focusout'){
				$('.data_sch_list_2').addClass('display_none');
				$(".all_src_data_option").show();
			}
			if(e.type=='change'){
				$("#btn2").append(in_html_2);
				$("#btn2").removeClass('display_none');
				$("#srchBBB").val("");
				$("#srchBBB").css({'padding-left':'px'});
			}
			if((e.type=='keydown')&&(e.keyCode==13)){
				e.preventDefault();
				e.stopPropagation();
			}
			if(e.type=='keyup'){
				var k = $(this).val();
				$(".all_src_data_option").hide();
				var temp = $(".all_src_data_option:contains('" + k + "')");
				$(temp).show();
			}

			var badge_leng = $('.all_badge_wrap').find('.btn_badge_type2').length;
			all_wrap_width = parseInt($('.all_badge_wrap').css('width'));
			console.log('badge_leng = '+badge_leng);

			$(this).css({'padding-left':all_wrap_width+8});
            // $("#srchBBB").val("");

            if($('.all_badge_wrap').find('.btn_badge_type2').length > 9){
				$("#btn2").css({'width':'100%', 'height':'33px'});
				$('.popup_filter').removeClass('display_none');
				$(".modal_confirm_3").removeClass('display_none');
            }else{
				$("#btn2").css({'width':'fit-content'});
			}
        });

		$('.data_form').find('.data_sch_list_2').on('mousedown','button', function(e){
			var data_all_length = $('.data_sch_list_2').find('.all_src_data_option').length;

			$("#srchBBB").val("");
			value_all = $(this).parent('li').data('value');
			index_all =  $(this).parent('li').data('index');
			var select_etc = $('#etc_all_sel');
			// $('.btn_badge_type2').remove();
			if($(this).parent().is('#etc_all_sel')){
				$('.popup_filter').removeClass('display_none');
				$(".modal_confirm_5").removeClass('display_none');
			}else{
				var out_html = '<div class="btn_badge_type2" data-index="'+index_all+'" data-value="'+value_all+'">'+value_all+'<a href="#" onclick="fnc_remove2(this)">닫기버튼</a></div>';
				$("#btn2").append(out_html);
				$("#btn2").removeClass('display_none');
				$("#srchBBB").val("");
				$('.data_sch_list_2').addClass('display_none');
				$(this).parent('.all_src_data_option').addClass('display_none');
				all_badge_arr();
			}
		});

        fnc_remove1 = function(item){
        	$(item).parent().remove();
			$("#btn1").addClass('display_none');
			solo_badge_arr();
        };

        fnc_remove2 = function(item){
			var chain_index =  $(item).parent('.btn_badge_type2').data('index');

			console.log('badge index = '+chain_index);
			$(item).parent().remove();
			$('.data_sch_list_2 ').find('.all_src_data_option_'+chain_index).removeClass('display_none');
			if($('.all_badge_wrap').find('.btn_badge_type2').length < 10){
				console.log('delete badge.');
				$("#btn2").css({'width':'fit-content'});
			}else{
				$("#btn2").css({'width':'100%', 'height':'33px'});
			}
			all_badge_arr();
        };
	    
		$('.modal_confirm_4').find('.etc_create_btn').on('click',function(e){
			var create_option_solo =  $('.modal_confirm_4').find('.etc_create_input').val();
			var solo_length = $('.data_sch_list_1').find('.all_src_data_option').length;
			var solo_li_create = '<li data-index="'+solo_length+'" data-value="'+create_option_solo+'" class="solo_src_data_option solo_src_data_option_'+solo_length+'"><button tabindex="0">'+create_option_solo+'</button></li>';
			var solo_op_create = '<option value="'+create_option_solo+'">'+create_option_solo+'</option>';

			console.log('create_option = '+create_option_solo);
			$('.data_sch_list_1').prepend(solo_li_create);
			$('#list1_select').prepend(solo_op_create);
			$('.etc_create_input').val('');
			$('.popup_filter').addClass('display_none');
			$('.modal_confirm_4').addClass('display_none');
		});

		$('.modal_confirm_5').find('.etc_create_btn').on('click',function(e){
			var create_option_all =  $('.modal_confirm_5').find('.etc_create_input').val();
			var all_length = $('.data_sch_list_2').find('.all_src_data_option').length;
			var all_li_create = '<li data-index="'+all_length+'" data-value="'+create_option_all+'" class="all_src_data_option all_src_data_option_'+all_length+'"><button tabindex="0">'+create_option_all+'</button></li>';
			var all_op_create = '<option value="'+create_option_all+'">'+create_option_all+'</option>';

			console.log('create_option = '+create_option_all);
			$('.data_sch_list_2').prepend(all_li_create);
			$('#list2_select').prepend(all_op_create);
			$('.etc_create_input').val('');
			$('.popup_filter').addClass('display_none');
			$('.modal_confirm_5').addClass('display_none');
		});

		function all_badge_arr(){ // 뱃지 복수 등록 부분 data-value 값 추출 함수로 변수 all_badge_pipe_wrap 에서 string 으로 처리 된 배열을 가짐.
			var all_badge_pipe;
			var all_badge_pipe_wrap = new Array(); // 복수 badge 의 data-value 값 string 묶음;
			var all_badge_index;
			var all_badge_index_wrap = new Array();

			$('.all_badge_wrap').find('[data-value]').each(function(){
				all_badge_pipe = $(this).attr('data-value');
				all_badge_pipe_wrap += String(all_badge_pipe)+' | ';
				all_badge_index = $(this).attr('data-index');
				all_badge_index_wrap += String(all_badge_index)+' | ';
				
				console.log(all_badge_pipe_wrap+' /data-value/ '+all_badge_index_wrap);
			});

			// 순환 기준을 data-index로 하고자 하는 경우 사용 - 상기의 data-value 순환 기준과 중복 사용 금지(값이 중복되어 변수에 입력 됨).
			// $('.all_badge_wrap').find('[data-index]').each(function(){
			// 	all_badge_pipe = $(this).attr('data-value');
			// 	all_badge_pipe_wrap += String(all_badge_pipe)+' | ';
			// 	all_badge_index = $(this).attr('data-index');
			// 	all_badge_index_wrap += String(all_badge_index)+' | ';
				
			// 	console.log(all_badge_pipe_wrap+' /data-index/ '+all_badge_index_wrap);
			// });
		};

		function solo_badge_arr(){ // 뱃지 단수 등록 부분 data-value 값 추출 함수로 변수 solo_badge_pipe 에서 string 으로 처리 된 값을 가짐.
			var solo_badge_pipe = String($('.solo_badge_wrap').find('.btn_badge_type1').data('value'));
			var solo_badge_index = String($('.solo_badge_wrap').find('.btn_badge_type1').data('index'));

			// 순환식으로 사용 시 이용
			// $('.solo_badge_wrap').find('[data-value]').each(function(){
			// 	solo_badge_pipe = $(this).attr('data-value');
			// 	solo_badge_pipe_wrap += String(solo_badge_pipe)+' | ';
			// 	solo_badge_index = $(this).attr('data-index');
			// 	solo_badge_index_wrap += String(solo_badge_index)+' | ';
				
			// 	console.log(solo_badge_pipe_wrap+' /data-value/ '+solo_badge_index_wrap);
			// });

			// 순환식으로 사용 시 이용 - 순환 기준을 data-index로 하고자 하는 경우 사용 - 상기의 data-value 순환 기준과 중복 사용 금지(값이 중복되어 변수에 입력 됨).
			// $('.solo_badge_wrap').find('[data-index]').each(function(){
			// 	solo_badge_pipe = $(this).attr('data-value');
			// 	solo_badge_pipe_wrap += String(solo_badge_pipe)+' | ';
			// 	solo_badge_index = $(this).attr('data-index');
			// 	solo_badge_index_wrap += String(solo_badge_index)+' | ';
				
			// 	console.log(solo_badge_pipe_wrap+' /data-index/ '+solo_badge_index_wrap);
			// });
			console.log(solo_badge_pipe+' / '+solo_badge_index);
		};
		// ---------------------------------------------------

		// ------- 업로드 파일 목록 부분 삭제 동작 예시 부분 ----
		$('.delete_btn').on('click', function(e){
			console.log('delete file name.');
			$(summon_file_this).remove();
			$('.popup_filter').addClass('display_none');
			$('.modal_confirm_1').addClass('display_none');
		});
		// ---------------------------------------------------
		// -----------------------------------------------
	});
	return false;
});
