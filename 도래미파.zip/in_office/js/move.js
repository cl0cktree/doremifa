$(function(){
	/*loader 제어*/
	$(document).ready(function(){
		function autoResize(textarea) {
			textarea.style.height = 'auto';
			textarea.style.height = textarea.scrollHeight + 'px';
			console.log(textarea.scrollHeight + 'px')
		  }
	});
	// return false;
});
